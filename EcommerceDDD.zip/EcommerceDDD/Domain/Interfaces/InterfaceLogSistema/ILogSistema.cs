﻿using Domain.Interfaces.Generics;
using Entities.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Interfaces.InterfaceLogSistema
{
    public interface ILogSistema : IGeneric<LogSistema>
    {
    }
}
