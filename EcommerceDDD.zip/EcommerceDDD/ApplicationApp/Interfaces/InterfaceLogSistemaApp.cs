﻿using Entities.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationApp.Interfaces
{
    public interface InterfaceLogSistemaApp : InterfaceGenericaApp<LogSistema>
    {
    }
}
